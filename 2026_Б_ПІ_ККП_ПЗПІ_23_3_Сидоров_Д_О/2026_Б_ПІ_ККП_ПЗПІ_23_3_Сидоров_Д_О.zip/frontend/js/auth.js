const loginForm = document.getElementById("loginForm");

if (loginForm) {

    loginForm.addEventListener("submit", async (e) => {

        e.preventDefault();

        const username =
            document.getElementById("username").value;

        const password =
            document.getElementById("password").value;

        try {

            const response = await fetch(
                "http://localhost:3000/api/login",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        username,
                        password
                    })
                }
            );

            const data = await response.json();

            if (!response.ok) {
                alert(data.message);
                return;
            }

            localStorage.setItem(
                "token",
                data.token
            );

            localStorage.setItem(
                "user",
                JSON.stringify(data.user)
            );

            alert("Вхід успішний!");

            window.location.href = "index.html";

        } catch (error) {

            console.error(error);

            alert(
                "Помилка підключення до сервера"
            );
        }
    });
}

const accountUsername = document.getElementById("accountUsername");

if (accountUsername) {
    const user = JSON.parse(localStorage.getItem("user"));

    if (!user) {
        window.location.href = "login.html";
    } else {
        document.getElementById("accountUsername").textContent = user.username;
        document.getElementById("accountEmail").textContent = user.email;
        document.getElementById("accountRole").textContent =
            user.role === "admin" ? "Адміністратор" : "Відвідувач";

        const tableRow = document.getElementById("tableRow");
        const accountTable = document.getElementById("accountTable");
        const adminLink = document.getElementById("adminLink");

        if (user.role === "admin") {
            tableRow.style.display = "none";
            adminLink.style.display = "block";
        } else {
            accountTable.textContent = user.table_number;
            adminLink.style.display = "none";
        }
    }
}

const logoutBtn = document.getElementById("logoutBtn");

if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
        const confirmLogout = confirm("Ви дійсно хочете вийти з акаунта?");

        if (!confirmLogout) {
            return;
        }

        localStorage.removeItem("token");
        localStorage.removeItem("user");
        localStorage.removeItem("cart");

        window.location.href = "login.html";
    });
}