const protectedUser = JSON.parse(localStorage.getItem("user"));

if (!protectedUser) {
    window.location.href = "login.html";
}