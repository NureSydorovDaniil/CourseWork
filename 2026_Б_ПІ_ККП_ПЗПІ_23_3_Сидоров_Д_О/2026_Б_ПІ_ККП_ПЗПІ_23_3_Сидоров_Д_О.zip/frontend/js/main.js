const products = [
    { id: 1, name: "Чай чорний", category: "Напої", price: 35, description: "Класичний чорний чай", image: "../images/drinks/black_tea.jpg" },
    { id: 2, name: "Чай зелений", category: "Напої", price: 35, description: "Ароматний зелений чай", image: "../images/drinks/green_tea.jpg" },
    { id: 3, name: "Кава американо", category: "Напої", price: 45, description: "Класична чорна кава", image: "../images/drinks/americano.jpg" },
    { id: 4, name: "Кава лате", category: "Напої", price: 65, description: "Кава з молоком та ніжною пінкою", image: "../images/drinks/latte.jpg" },
    { id: 5, name: "Кава капучино", category: "Напої", price: 60, description: "Кава з молочною пінкою", image: "../images/drinks/capuchino.jpg" },
    { id: 6, name: "Вода", category: "Напої", price: 30, description: "Мінеральна вода", image: "../images/drinks/voda.jpg" },
    { id: 7, name: "Лимонад класичний", category: "Напої", price: 70, description: "Освіжаючий лимонад з лимоном", image: "../images/drinks/lemonade.jpg" },
    { id: 8, name: "Лимонад-мохіто", category: "Напої", price: 85, description: "Лимонад з м'ятою та лаймом", image: "../images/drinks/mohito.jpg" },
    { id: 9, name: "Лимонад апельсиновий", category: "Напої", price: 80, description: "Апельсиновий освіжаючий лимонад", image: "../images/drinks/lemonade_orange.jpg" },
    { id: 10, name: "Лимонад ягідний", category: "Напої", price: 90, description: "Ягідний лимонад з насиченим смаком", image: "../images/drinks/lemonade_mix.jpg" },

    { id: 11, name: "Борщ український", category: "Супи", price: 120, description: "Традиційний борщ зі сметаною", image: "../images/soups/borsh.jpg" },
    { id: 12, name: "Крем-суп грибний", category: "Супи", price: 135, description: "Ніжний крем-суп з печериць", image: "../images/soups/cream_soup.jpg" },
    { id: 13, name: "Солянка", category: "Супи", price: 140, description: "Ситний суп з м'ясом та спеціями", image: "../images/soups/solyanka.jpg" },
    { id: 14, name: "Окрошка", category: "Супи", price: 110, description: "Холодний літній суп", image: "../images/soups/okroshka.jpg" },
    { id: 15, name: "Овочевий суп", category: "Супи", price: 100, description: "Легкий суп зі свіжих овочів", image: "../images/soups/vegetable_soup.jpg" },

    { id: 16, name: "Піца чотири сири", category: "Піца", price: 280, description: "Моцарела, дорблю, пармезан, чедер", image: "../images/pizza/pizza_4.jpg" },
    { id: 17, name: "Піца Маргарита", category: "Піца", price: 210, description: "Томатний соус, моцарела, базилік", image: "../images/pizza/pizza_margarita.jpg" },
    { id: 18, name: "Піца пепероні", category: "Піца", price: 260, description: "Пепероні, моцарела, томатний соус", image: "../images/pizza/pizza_peperoni.jpg" },
    { id: 19, name: "Піца гавайська", category: "Піца", price: 250, description: "Курка, ананас, сир, томатний соус", image: "../images/pizza/pizza_gavai.jpg" },

    { id: 20, name: "Суші-сет Філадельфія", category: "Суші-сети", price: 420, description: "Роли з лососем, сиром та огірком", image: "../images/sushi/sushi_1.jpg" },
    { id: 21, name: "Суші-сет Каліфорнія", category: "Суші-сети", price: 390, description: "Роли з крабом, авокадо та ікрою", image: "../images/sushi/sushi_2.jpg" },
    { id: 22, name: "Запечений сет", category: "Суші-сети", price: 450, description: "Набір запечених ролів", image: "../images/sushi/sushi_3.jpg" },
    { id: 23, name: "Гавайський сет", category: "Суші-сети", price: 430, description: "Сет з ніжним смаком та соусами", image: "../images/sushi/sushi_4.jpg" },
    { id: 24, name: "Сімейний сет", category: "Суші-сети", price: 650, description: "Великий сет для компанії", image: "../images/sushi/sushi_5.jpg" },

    { id: 25, name: "Чізкейк", category: "Десерти", price: 115, description: "Ніжний сирний десерт", image: "../images/desserts/chezcake.jpg" },
    { id: 26, name: "Тірамісу", category: "Десерти", price: 130, description: "Італійський десерт з кавовим смаком", image: "../images/desserts/teramesu.jpg" },
    { id: 27, name: "Наполеон", category: "Десерти", price: 120, description: "Класичний листковий торт", image: "../images/desserts/napoleon.jpg" },
    { id: 28, name: "Шоколадний мафін", category: "Десерти", price: 90, description: "М'який мафін з шоколадом", image: "../images/desserts/mafin.jpg" },
    { id: 29, name: "Шоколадний торт", category: "Десерти", price: 150, description: "Насичений шоколадний десерт", image: "../images/desserts/tort.jpg" }
];

const productsGrid = document.getElementById("productsGrid");
const searchInput = document.getElementById("searchInput");
const categoryFilter = document.getElementById("categoryFilter");
const priceFilter = document.getElementById("priceFilter");

function displayProducts(items) {
    productsGrid.innerHTML = "";

    items.forEach(product => {
        const card = document.createElement("div");
        card.className = "product-card";

        card.innerHTML = `
            <div class="product-image">
            <img src="${product.image}" alt="${product.name}">
            </div>
            <h3>${product.name}</h3>
            <p class="product-category">${product.category}</p>
            <p class="product-description">${product.description}</p>
            <div class="product-bottom">
                <span>${product.price} грн</span>
                <button onclick="addToCart(${product.id})">Додати</button>
            </div>
        `;

        productsGrid.appendChild(card);
    });
}

function filterProducts() {
    const searchText = searchInput.value.toLowerCase();
    const selectedCategory = categoryFilter.value;
    const selectedPrice = priceFilter.value;

    let filtered = products.filter(product => {
        const matchesSearch = product.name.toLowerCase().includes(searchText);
        const matchesCategory = selectedCategory === "all" || product.category === selectedCategory;
        const matchesPrice = selectedPrice === "all" || product.price <= Number(selectedPrice);

        return matchesSearch && matchesCategory && matchesPrice;
    });

    displayProducts(filtered);
}

function addToCart(productId) {

    const product = products.find(
        p => p.id === productId
    );

    let cart =
        JSON.parse(localStorage.getItem("cart")) || [];

    const existingItem =
        cart.find(item => item.id === productId);

    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({
            ...product,
            quantity: 1
        });
    }

    localStorage.setItem(
        "cart",
        JSON.stringify(cart)
    );

    alert(`${product.name} додано до кошика`);
}

searchInput.addEventListener("input", filterProducts);
categoryFilter.addEventListener("change", filterProducts);
priceFilter.addEventListener("change", filterProducts);

displayProducts(products);