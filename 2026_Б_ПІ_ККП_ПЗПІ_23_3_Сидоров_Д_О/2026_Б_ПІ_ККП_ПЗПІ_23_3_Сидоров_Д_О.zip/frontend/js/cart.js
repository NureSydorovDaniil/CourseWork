const cartItems =
    document.getElementById("cartItems");

const totalPrice =
    document.getElementById("totalPrice");

function renderCart() {

    let cart =
        JSON.parse(localStorage.getItem("cart")) || [];

    cartItems.innerHTML = "";

    let total = 0;

    if (cart.length === 0) {

        cartItems.innerHTML =
    `<div class="empty-cart">
        <h2>Кошик порожній</h2>
        <p>Додайте страви або напої з меню</p>
    </div>`;

        totalPrice.textContent = "0";

        return;
    }

    cart.forEach(item => {

        total += item.price * item.quantity;

        const card =
            document.createElement("div");

        card.className = "cart-item";

        card.innerHTML = `
            <h3>${item.name}</h3>

            <p>${item.price} грн</p>

            <div class="cart-controls">

                <button
                    onclick="decreaseQuantity(${item.id})">
                    -
                </button>

                <span>${item.quantity}</span>

                <button
                    onclick="increaseQuantity(${item.id})">
                    +
                </button>

            </div>
        `;

        cartItems.appendChild(card);
    });

    totalPrice.textContent = total;
}

function increaseQuantity(id) {

    let cart =
        JSON.parse(localStorage.getItem("cart")) || [];

    const item =
        cart.find(i => i.id === id);

    item.quantity++;

    localStorage.setItem(
        "cart",
        JSON.stringify(cart)
    );

    renderCart();
}

function decreaseQuantity(id) {

    let cart =
        JSON.parse(localStorage.getItem("cart")) || [];

    const item =
        cart.find(i => i.id === id);

    item.quantity--;

    if (item.quantity <= 0) {

        cart =
            cart.filter(i => i.id !== id);
    }

    localStorage.setItem(
        "cart",
        JSON.stringify(cart)
    );

    renderCart();
}

async function placeOrder() {
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    const user = JSON.parse(localStorage.getItem("user"));

    if (!user) {
        alert("Спочатку увійдіть в акаунт");
        window.location.href = "login.html";
        return;
    }

    if (cart.length === 0) {
        alert("Кошик порожній");
        return;
    }

    const total = cart.reduce((sum, item) => {
        return sum + item.price * item.quantity;
    }, 0);

    try {
        const response = await fetch("http://localhost:3000/api/orders", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                table_number: user.table_number,
                total_price: total,
                items: cart
            })
        });

        const data = await response.json();

        if (!response.ok) {
            alert(data.message);
            return;
        }

        alert("Замовлення успішно оформлено!");

        localStorage.removeItem("cart");

        renderCart();

    } catch (error) {
        console.error(error);
        alert("Помилка відправлення замовлення");
    }
}

renderCart();