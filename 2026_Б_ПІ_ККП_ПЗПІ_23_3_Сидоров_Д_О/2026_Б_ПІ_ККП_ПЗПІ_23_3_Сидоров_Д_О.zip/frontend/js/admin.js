const currentUser = JSON.parse(localStorage.getItem("user"));

if (!currentUser) {
    window.location.href = "login.html";
}

if (currentUser && currentUser.role !== "admin") {
    alert("У вас немає доступу до адмін-панелі");
    window.location.href = "index.html";
}

const adminOrders = document.getElementById("adminOrders");

async function loadOrders() {
    try {
        const response = await fetch("http://localhost:3000/api/orders");
        const orders = await response.json();

        renderOrders(orders);

    } catch (error) {
        console.error(error);
        adminOrders.innerHTML = `
            <div class="empty-cart">
                <h2>Помилка завантаження</h2>
                <p>Не вдалося отримати замовлення з сервера</p>
            </div>
        `;
    }
}

function renderOrders(orders) {
    adminOrders.innerHTML = "";

    if (orders.length === 0) {
        adminOrders.innerHTML = `
            <div class="empty-cart">
                <h2>Активних замовлень немає</h2>
                <p>Нові замовлення будуть відображатися тут</p>
            </div>
        `;
        return;
    }

    orders.forEach(order => {
        const card = document.createElement("div");
        card.className = "admin-order-card";

        const itemsHtml = order.items.map(item => `
        <li>
            ${item.product_name} × ${item.quantity}
            <span>${item.product_price * item.quantity} грн</span>
        </li>
`).join("");

        card.innerHTML = `
            <div class="admin-order-header">
                <h3>Стіл №${order.table_number}</h3>
                <span>${order.created_at}</span>
            </div>

            <ul class="admin-order-list">
                ${itemsHtml}
            </ul>

            <div class="admin-order-total">
                Сума: ${order.total_price} грн
            </div>

            <button class="complete-btn" onclick="completeOrder(${order.id})">
            Завершити замовлення
            </button>
        `;

        adminOrders.appendChild(card);
    });
}

async function completeOrder(orderId) {
    const confirmDelete = confirm("Завершити це замовлення?");

    if (!confirmDelete) {
        return;
    }

    try {
        const response = await fetch(`http://localhost:3000/api/orders/${orderId}`, {
            method: "DELETE"
        });

        const data = await response.json();

        if (!response.ok) {
            alert(data.message);
            return;
        }

        alert("Замовлення завершено!");

        loadOrders();

    } catch (error) {
        console.error(error);
        alert("Помилка завершення замовлення");
    }
}

loadOrders();
setInterval(loadOrders, 5000);