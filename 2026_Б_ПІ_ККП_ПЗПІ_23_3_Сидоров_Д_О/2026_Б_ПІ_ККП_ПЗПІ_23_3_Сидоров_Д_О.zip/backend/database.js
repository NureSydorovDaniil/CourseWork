const sqlite3 = require("sqlite3").verbose();
const path = require("path");
const bcrypt = require("bcrypt");

const dbPath = path.join(__dirname, "database", "restaurant.db");

const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error("Database connection error:", err.message);
    } else {
        console.log("Connected to SQLite database");
    }
});

db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            table_number INTEGER,
            role TEXT NOT NULL
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            price REAL NOT NULL,
            image TEXT,
            category_id INTEGER,
            FOREIGN KEY (category_id) REFERENCES categories(id)
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            table_number INTEGER NOT NULL,
            total_price REAL NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    db.run(`
    CREATE TABLE IF NOT EXISTS order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER,
        product_id INTEGER,
        product_name TEXT,
        product_price REAL,
        quantity INTEGER,
        FOREIGN KEY (order_id) REFERENCES orders(id)
    )
    `);

    const users = [
        ["table_1", "table1@gmail.com", "12345678", 1, "user"],
        ["table_2", "table2@gmail.com", "12345678", 2, "user"],
        ["table_3", "table3@gmail.com", "12345678", 3, "user"],
        ["table_4", "table4@gmail.com", "12345678", 4, "user"],
        ["admin", "admin@gmail.com", "admin123", null, "admin"]
    ];

    users.forEach(user => {
        const hashedPassword = bcrypt.hashSync(user[2], 10);

        db.run(`
            INSERT OR IGNORE INTO users 
            (username, email, password, table_number, role)
            VALUES (?, ?, ?, ?, ?)
        `, [user[0], user[1], hashedPassword, user[3], user[4]]);
    });
});

module.exports = db;