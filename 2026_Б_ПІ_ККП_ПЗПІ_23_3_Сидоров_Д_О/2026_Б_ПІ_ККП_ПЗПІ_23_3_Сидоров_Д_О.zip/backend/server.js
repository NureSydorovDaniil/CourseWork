const express = require("express");
const cors = require("cors");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const db = require("./database");

const app = express();

app.use(cors());
app.use(express.json());

const SECRET_KEY = "restaurant_secret_key";

app.get("/", (req, res) => {
    res.send("Restaurant system API is running");
});

app.post("/api/login", (req, res) => {
    const { username, password } = req.body;

    db.get(
        "SELECT * FROM users WHERE username = ?",
        [username],
        async (err, user) => {
            if (err) {
                return res.status(500).json({ message: "Server error" });
            }

            if (!user) {
                return res.status(401).json({ message: "Невірний логін або пароль" });
            }

            const isPasswordValid = await bcrypt.compare(password, user.password);

            if (!isPasswordValid) {
                return res.status(401).json({ message: "Невірний логін або пароль" });
            }

            const token = jwt.sign(
                {
                    id: user.id,
                    username: user.username,
                    role: user.role,
                    table_number: user.table_number
                },
                SECRET_KEY,
                { expiresIn: "2h" }
            );

            res.json({
                message: "Login successful",
                token,
                user: {
                    id: user.id,
                    username: user.username,
                    email: user.email,
                    role: user.role,
                    table_number: user.table_number
                }
            });
        }
    );
});

app.post("/api/orders", (req, res) => {
    const { table_number, total_price, items } = req.body;

    db.run(
        `
        INSERT INTO orders (table_number, total_price)
        VALUES (?, ?)
        `,
        [table_number, total_price],
        function (err) {
            if (err) {
                return res.status(500).json({
                    message: "Помилка створення замовлення"
                });
            }

            const orderId = this.lastID;

            items.forEach(item => {
                db.run(
                    `
                    INSERT INTO order_items
                    (order_id, product_id, product_name, product_price, quantity)
                    VALUES (?, ?, ?, ?, ?)
                    `,
                    [
                        orderId,
                        item.id,
                        item.name,
                        item.price,
                        item.quantity
                    ]
                );
            });

            res.json({
                message: "Замовлення створено"
            });
        }
    );
});

app.get("/api/orders", (req, res) => {
    db.all(
        `
        SELECT *
        FROM orders
        ORDER BY created_at DESC
        `,
        [],
        (err, orders) => {
            if (err) {
                return res.status(500).json({
                    message: "Помилка отримання замовлень"
                });
            }

            const promises = orders.map(order => {
                return new Promise((resolve, reject) => {
                    db.all(
                        `
                        SELECT *
                        FROM order_items
                        WHERE order_id = ?
                        `,
                        [order.id],
                        (err, items) => {
                            if (err) {
                                reject(err);
                            } else {
                                resolve({
                                    ...order,
                                    items
                                });
                            }
                        }
                    );
                });
            });

            Promise.all(promises)
                .then(result => res.json(result))
                .catch(() => {
                    res.status(500).json({
                        message: "Помилка отримання складу замовлення"
                    });
                });
        }
    );
});

app.delete("/api/orders/:id", (req, res) => {
    const orderId = req.params.id;

    db.run(
        "DELETE FROM order_items WHERE order_id = ?",
        [orderId],
        (err) => {
            if (err) {
                return res.status(500).json({
                    message: "Помилка видалення складу замовлення"
                });
            }

            db.run(
                "DELETE FROM orders WHERE id = ?",
                [orderId],
                (err) => {
                    if (err) {
                        return res.status(500).json({
                            message: "Помилка видалення замовлення"
                        });
                    }

                    res.json({
                        message: "Замовлення завершено"
                    });
                }
            );
        }
    );
});

const PORT = 3000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});